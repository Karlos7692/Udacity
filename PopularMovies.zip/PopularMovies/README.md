To successfully download movies to the app please supply an API key
in file:

 ~/PopularMovies/app/src/main/java/com/nelson/karl/popularmovies/data/utils/APIUtil.java

You will see a TODO above the API_KEY constant.

To register for an account please see the themovieDB API for details.


